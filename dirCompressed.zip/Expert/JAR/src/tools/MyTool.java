package tools;

public class MyTool {
    public MyTool(){

    }
    public void doSomeyhing(){
        System.out.println("Hello");
    }

}
